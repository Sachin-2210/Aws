#!/bin/bash
echo "Deployed via CodeDeploy" > /var/www/html/info.txt
